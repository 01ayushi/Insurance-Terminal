<?php 
include('header.php');
?>
<title>insuranceterminal.in : Provides and Suggest Best Availiable Options</title>
<script type="text/javascript" src="script/form.js"></script>

<style type="text/css">
  #register_form fieldset:not(:first-of-type) {
    display: none;
  }
</style>
<?php include('container.php');?>

<div class="container">
	<img src="./images/Insurance.jpeg" class="img-fluid center-block" height="350px" alt="Responsive image">
	<h2>Get Free Quotes In Just 3 Steps</h2>		
	<div class="progress">
	<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
	</div>
	<div class="alert alert-success hide"></div>	
	<form id="register_form" novalidate action="multi_form_action.php"  method="post">	
	<fieldset>
	<h2>Step 1: Please share us your details</h2>
	<div class="form-group">
	<label for="email">Email address*</label>
	<input type="email" class="form-control" required id="email" name="email" placeholder="Email">
	</div>
	<div class="form-group">
	<label for="password">Phone Number*</label>
	<input type="" class="form-control" name="password" id="password" placeholder="Phone Number">
	</div>
	<input type="button" class="next-form btn btn-info" value="Next" />
	</fieldset>	
	<fieldset>
	<h2> Step 2: Add Motor Policy Details</h2>
	<div class="form-group">
	<label for="first_name">Registration Number</label>
	<input type="text" class="form-control" name="first_name" id="first_name" placeholder="Vehicle Registration Number">
	</div>
	<div class="form-group">
	<label for="last_name">Insurance Policy Validity</label>
	<input type="date" class="form-control" name="last_name" id="last_name" placeholder="Insurance Policy Validity">
	</div>
	<input type="button" name="previous" class="previous-form btn btn-default" value="Previous" />
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>
	
	<fieldset>
	<h2>Step 3: Please Provide Current Policy Details</h2>
	<div class="form-group">
	<label for="mobile">Current Insurance Policy Name*</label>
	<input type="text" class="form-control" name="mobile" id="mobile" placeholder="Current Insurance Policy Provider">
	</div>
	<div class="form-group">
	<label for="address">No Claim Bonus Information</label>
	<textarea  class="form-control" name="address" placeholder="NCD Details If Any"></textarea>
	</div>
	<input type="button" name="previous" class="previous-form btn btn-default" value="Previous" />
	<input type="submit" name="submit" class="submit btn btn-success" value="Click To Download Free Quotes" />
	</fieldset>
	</form>
		
		
		
	<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="http://www.insuranceterminal.in" title="">Know More About Motor Insurance</a>			
	</div>	
</div>	
<?php include('./footer.php');?> 