</head>
<body>
<!--
<div role="navigation" class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a href="http://www.insuranceterminal.in" class="navbar-brand">insuranceterminal.in</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="http://www.insuranceterminal.in">Home</a></li>
           
          </ul>
         
        </div>
      </div>
    </div>
  commented -->
  <header id="header">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="../index.html"><span>Insurance Terminal</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="../index.html#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="../index.html#about">About Us</a></li>
          <li><a class="nav-link scrollto" href="../index.html#services">Services</a></li>
          <!--
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li> -->
          <!--<li><a class="nav-link scrollto" href="#team">Team</a></li>-->
          <li><a class="nav-link scrollto" href="../index.html#services">Products</a></li>
          <li><a class="nav-link scrollto" href="../index.html#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
	
	<!--<div class="container" style="min-height:500px;">-->
	<!--<div class=''>
	</div>-->