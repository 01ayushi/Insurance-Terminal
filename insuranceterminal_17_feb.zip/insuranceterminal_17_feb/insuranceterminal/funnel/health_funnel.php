<?php 
include('header.php');
?>
<title>insuranceterminal.in : Provides and Suggest Best Availiable Options</title>
<script type="text/javascript" src="script/form.js"></script>

<style type="text/css">
  #register_form fieldset:not(:first-of-type) {
    display: none;
  }
</style>
<?php include('container.php');?>

<div class="hero-container col-sm-12 my-auto">
	<img src="./images/Medical.png" class="img-fluid center-block" alt="Responsive image">
	<h2>Get Free Quotes In Just 4 Steps</h2>		
	<div class="progress">
	<div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
	</div>
	<div class="alert alert-success hide"></div>	
	<form id="register_form" novalidate action="health_multi_form_action.php"  method="post">	
	<fieldset>
	<h2>Step 1: Please share us your details</h2>
	<div class="form-group">
	<label for="email">Email address*</label>
	<input type="email" class="form-control" required id="email" name="email" placeholder="Email">
	</div>
	<div class="form-group">
	<label for="phonenumber">Phone Number*</label>
	<input type="" class="form-control" name="phonenumber" id="phonenumber" placeholder="Phone Number">
	</div>
	<input type="button" class="next-form btn btn-info" value="Next" />
	</fieldset>	
	<fieldset>
	<h2> Step 2: Please provide some additional details</h2>
	<div class="form-group">
	<label for="no_insured_person">Numbers of persons to be Insured</label>
	<input type="text" class="form-control" name="no_insured_person" id="no_insured_person" placeholder="Numbers of persons to be Insured">
	</div>
	<div class="form-group">
	<label for="age_eldest_member">Age of Eldest Member</label>
	<input type="text" class="form-control" name="age_eldest_member" id="age_eldest_member" placeholder="Age of Eldest Member">
	</div>
	<input type="button" name="previous" class="previous-form btn btn-default" value="Previous" />
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>

	<fieldset>
	<h2> Step 3: Please provide some additional details</h2>
	<div class="form-group">
	<label for="sum_insured">Sum Insured Required</label>
	<input type="text" class="form-control" name="sum_insured" id="sum_insured" placeholder="Sum Insured Required">
	</div>
	<div class="form-group">
	<label for="custom_requirement">Any Custom Requirement</label>
	<input type="textbox" class="form-control" name="custom_requirement" id="custom_requirement" placeholder="Any custom requirement">
	</div>
	<input type="button" name="previous" class="previous-form btn btn-default" value="Previous" />
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>
	
	<fieldset>
	<h2>Step 4: Please Provide Current Policy Details</h2>
	<div class="form-group">
	<label for="insurance_policy">Current Insurance Policy Name*</label>
	<input type="text" class="form-control" name="insurance_policy" id="insurance_policy" placeholder="Current Insurance Policy Provider">
	</div>
	<div class="form-group">
	<label for="ncb">No Claim Bonus Information</label>
	<textarea  class="form-control" name="ncb" placeholder="NCB Details If Any"></textarea>
	</div>
	<input type="button" name="previous" class="previous-form btn btn-default" value="Previous" />
	<input type="submit" name="submit" class="submit btn btn-success" value="Click To Download Free Quotes" />
	</fieldset>
	</form>
		
		
		
	<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="../blog.html#healthInsurance" title="">Know More About Health Insurance</a>			
	</div>	
</div>
<?php include('./footer.php');?> 