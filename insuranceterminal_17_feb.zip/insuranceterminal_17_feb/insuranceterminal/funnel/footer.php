<div class="insert-post-ads1" style="margin-top:20px;">
	  <!-- ======= Footer ======= -->
  <footer class="bg-light">
    <div class="footer-top">
      <div class="container">
        <div class="row">

        </div>
      </div>
    </div>
    <hr>
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>InsuranceTerminal</span></strong>. All Rights Reserved
      </div>
      
    </div>
  </footer><!-- End Footer -->
  </div>
</body></html>

